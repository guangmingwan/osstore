<?php
/**
 * Luxe
 * Bestsellers module
 *
 * @category   Luxe 
 * @package    Luxe_Bestsellers
 */


/**
 * Bestsellers data helper
 *
 * @category   Luxe
 * @package    Luxe_Bestsellers
 */
class Luxe_Bestsellers_Helper_Data extends Mage_Core_Helper_Abstract
{

}
