<?php
/**
 * Luxe
 * MostViewed module
 *
 * @category   Luxe 
 * @package    Luxe_MostViewed
 */


/**
 * MostViewed data helper
 *
 * @category   Luxe
 * @package    Luxe_MostViewed
 */
class Luxe_MostViewed_Helper_Data extends Mage_Core_Helper_Abstract
{

}
