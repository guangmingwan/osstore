<?php

class JobsController extends Controller
{
	public $layout='column1';

	/**
	 * @var CActiveRecord the currently loaded data model instance.
	 */
	private $_model;

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to access 'index' and 'view' actions.
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated users to access all actions
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}
 

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		if(isset($_POST['branch']))
		{
			$branch =$_POST['branch'];
			if(!strstr($branch,'*'))
			{
				$predictions = Jobs::model()->findAll("branch=:branch",array(":branch"=>$branch)); 
				if(empty($predictions))
				{
				$model = new Jobs();
				$model->branch= $branch;
				if($model->save())
					$this->redirect(array('index'));
				}
			}
		}
		
		 
		exec("git branch", $outs);
		$id = 0 ;
		$branches = array();
		$selectedV = 0;
		foreach($outs as $b)
		{
			$branches[] = array("id"=>trim($b),"title"=> trim($b));
			if(strstr($b,"*"))
			{
				$selectedV = trim($b);
			}
			$id++;
		}
		exec("git log -n 5",$outs2);
		$gitlog = implode("\r\n",$outs2);
		 
		//var_dump($branches); die();
		$predictions = Jobs::model()->findAll();
		$jobscount = count($predictions);

		$this->render('index',array(
			'model'=>$branches,
				'selectedV'=>$selectedV,
				"gitlog"=>$gitlog,
				"jobscount"=>$jobscount,
		));
	}

	 
}
