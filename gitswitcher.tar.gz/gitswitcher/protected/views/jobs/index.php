<script language="javascript">
function reload()
{
	window.location.reload();
}
</script>
选择分支:[待处理队列:<?php echo $jobscount;?>]
<?php $form=$this->beginWidget('CActiveForm'); ?>
<p><?php echo CHtml::dropDownList(
    "branch",
    $selectedV,
    CHtml::listData($model, "id", "title"));
?></p>
<div class="row buttons">
		<?php echo CHtml::button( '刷新', array('title'=>"刷新",'onclick'=>'js:reload()')  ); ?> 
		<?php echo CHtml::submitButton( '切换'  ); ?>
	</div>
 

<?php $this->endWidget(); ?>

<div class="row">
		<p><?php echo CHtml::label('分支的最后5条修改日至','content'); ?></p>
		<?php echo CHtml::textArea('gitlog',$gitlog,array('rows'=>30, 'cols'=>90)); ?> 
		 
	</div>
