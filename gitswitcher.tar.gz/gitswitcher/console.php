<?php  
//yiic.php  
  
// change the following paths if necessary  
$yiic=dirname(__FILE__).'/framework/yiic.php';  
$config=dirname(__FILE__).'/protected/config/console.php';  
  
require_once($yiic); 
