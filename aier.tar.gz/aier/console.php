<?php  
//yiic.php  
date_default_timezone_set("America/New_York");
  
// change the following paths if necessary  
$yiic=dirname(__FILE__).'/framework/yiic.php';  
$config=dirname(__FILE__).'/protected/config/console.php';  
  
require_once($yiic); 
